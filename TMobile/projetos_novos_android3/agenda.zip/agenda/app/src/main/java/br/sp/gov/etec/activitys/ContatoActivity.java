package br.sp.gov.etec.activitys;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import br.sp.gov.etec.R;

public class ContatoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato);
    }
}
