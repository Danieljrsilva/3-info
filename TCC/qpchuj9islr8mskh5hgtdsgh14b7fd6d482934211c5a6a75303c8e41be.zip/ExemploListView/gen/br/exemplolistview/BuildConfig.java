/** Automatically generated file. DO NOT MODIFY */
package br.exemplolistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}